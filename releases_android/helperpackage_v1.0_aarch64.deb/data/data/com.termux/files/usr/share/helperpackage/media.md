
---

# Media Manipulation

related packages:
* ffmpeg
* imagemagick
* chafa

## FFmpeg

FFmpeg is a command-line video and audio manipulation tool.
It allows you to **edit, convert, and process media files** easily.  
You can resize videos, convert formats, extract audio, and more.

---

## Converting Videos with FFmpeg

Examples:

- Convert MP4 to GIF:
```
ffmpeg -i input.mp4 -vf "fps=15,scale=320:-1:flags=lanczos" output.gif
```

Convert AVI to MP4:

```
ffmpeg -i input.avi output.mp4
```

Extract audio from video:

```
ffmpeg -i input.mp4 -q:a 0 -map a output.mp3
```

Check file information:

```
ffmpeg -i input.mp4
```

---

# ImageMagick

*ImageMagick* is a command-line image editing tool.
It lets you manipulate images: resize, crop, convert formats, and more.


---

## Basic Image Manipulation

Examples:

Resize an image:

```
magick input.png -resize 50% output.png
```

Convert image format:

```
magick input.jpg output.png
```
Crop an image:

```
magick input.jpg -crop 300x200+10+10 output.jpg
```

all the values in the commands can be adjusted to fill your necessities.

Combining Images into GIF

Using ImageMagick:
```
magick -delay 20 frame*.png animation.gif
```

---

## Chafa: Image to Ascii

you can see images in your terminal by just generating a **ASCII** art of the image!

the best tool to make this is with **chafa**

---

## characters to use with chafa;

### the characters are a very important option, because it will determine how your ascii will look like.

#### some useful fonts;
| font    | description                                                         |
|---------|---------------------------------------------------------------------|
| braille | it will fill the images with dots, consider using -fg-only flag.    |
| block   | it will fill the image with  blocks like "█", great for clear view. |
| alpha   | generates the ascii art with letters.                               |
|symbols  | generates the ascii art with symbols like "$" or "&"|

## Adjusting the XxY ASCII generation

you need to adjust it to fit your terminal width in most cases.

a template command to generate a ascii art using `block` font is:

```
chafa file.png -s 30x40 --symbols=block -c full
```

it is useful to save it with `>> file.txt` to use in the future with *fastfetch* *(check bash guide if you dont know yet what fastfetch is)*

---

Tips and Tricks

Converting videos to GIFs:

1. Optimization: High quality can create 20-30MB+ files. Keep it small for faster processing.


2. FPS: Enough frames for smooth playback, but too many increases file size.


3. Scale: Lower resolution keeps files lightweight and shareable.

##### a good command to use to make gifs from mp4 is:

```
ffmpeg -i video.mp4 -vf "fps=25,scale=230:-1:flags=lanczos" -c:v gif -f gif output.gif
```
adjust fps and scale as your necessities.

---

##### Other Tips:

Check media info before editing:

```
ffmpeg -i video.mp4
```

##### Preserve quality when converting videos:

```
ffmpeg -i input.mp4 -c:v libx264 -crf 18 output.mp4
```
