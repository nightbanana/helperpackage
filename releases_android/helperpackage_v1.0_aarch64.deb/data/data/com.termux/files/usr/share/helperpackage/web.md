# Web Tools Basics

Command-line tools for downloading, testing, and interacting with the web.

## curl

`curl` is a command-line tool to transfer data from or to a server using many protocols like HTTP, HTTPS, FTP, and more.

### Examples:
```
curl https://example.com
curl -O https://example.com/file.zip
curl -X POST -d "name=Zeppelin" https://api.example.com/user
```

---

## wget

`wget` is mainly used for downloading files or even entire websites.

### Examples:
```
wget https://example.com/file.zip
wget -r https://example.com/
```

---

## ping

`ping` checks if a host is reachable and measures response time.

### Example:
```
ping google.com
```

---

## ssh

`ssh` connects securely to remote machines using an encrypted connection.

### Example:
```
ssh user@server
```

---

## scp

`scp` is used to securely copy files between local and remote systems.

### Examples:
```
scp file.txt user@server:/home/user/
scp user@server:/path/file.txt .
```

---

## Tips

- Use `curl` + `jq` together to view JSON API data cleanly.  
- Use `wget` for large file downloads or full site backups.  
- Combine `ping` and `ssh` to test and connect to servers easily.
