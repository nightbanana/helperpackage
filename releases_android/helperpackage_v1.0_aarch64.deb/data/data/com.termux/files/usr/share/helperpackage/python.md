# Python in CLI

Python is a general-purpose programming language that can be used
directly from the command line to automate tasks, process data,
or create powerful scripts and tools.

## Installation

```
apt install python
```

## Running scripts

```
python script.py
```

You can also use Python interactively by typing:
```
python
```
---

## Package manager (pip)

`pip` is used to install Python libraries and modules.

```
pip install requests
```

To list installed packages:
```
pip list
```
---

## Useful CLI tips

* Run one-line commands directly:
  ```
  python -c "print('Hello CLI!')"
  ```
* Make scripts executable:
  ```
  chmod +x script.py
  ./script.py
  ```
* Use virtual environments to isolate dependencies:
  ```
  python -m venv env
  source env/bin/activate
  ```

---

## why Python is Important

in cli it will be very important because Python has a considerable number of useful packages and tools. 

---

### Optional: Node.js

If you prefer JavaScript for scripting, you can use Node.js:
```
apt install nodejs
```
```
node script.js
```
