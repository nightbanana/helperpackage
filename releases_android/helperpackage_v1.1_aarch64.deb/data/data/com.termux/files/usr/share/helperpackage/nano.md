# Text Editors

related packages:
* nano
* vim (and derivatives like neovim)
* emacs
* micro

## Nano

nano is a simple text editor that come in most part of Linux distributions.

in termux, nano comes as a pre-installed package and is very easy to use.

`nano [filename]` to create/open a file.

after writing your text, use `CTRL + O`, then press Enter and then `CTRL + X` to leave.

`CTRL + F` to search something in the text that matches your search

`CTRL + K` to cut a line

`CTRL + /` and column number/line number to go to that line

---

# vim (and derivatives)

## Vim, Vi and Neovim

Vim (Vi Improved) is a modal text editor that runs in the terminal.  
It’s fast, powerful, and entirely keyboard-driven.  
Unlike most editors, Vim has **modes** — meaning you type commands in one mode, and text in another.

## Modes Overview

| Mode | Description |
|------|--------------|
| Normal | For moving the cursor and running commands |
| Insert | For editing text |
| Visual | For selecting text blocks |
| Command | For entering commands that start with `:` |

To switch modes:  
- Press **`i`** to enter *Insert mode*  
- Press **`Esc`** to return to *Normal mode*  

---

## Basic Commands

| Action | Command |
|--------|----------|
| Save file | `:w` |
| Quit | `:q` |
| Save and quit | `:wq` |
| Force quit (discard changes) | `:q!` |
| Delete line | `dd` |
| Copy line | `yy` |
| Paste | `p` |
| Undo | `u` |
| Redo | `Ctrl + r` |


##### Tips and Tricks for vi

* Run `vimtutor` to learn Vim interactively — it’s built-in!  
* `nvim` (Neovim) is a modern Vim fork with extra features and Lua scripting.  
* You can open multiple files: `vim file1 file2`.  
* To move faster, use:  
  - `w` → jump to next word  
  - `b` → jump to previous word  
  - `gg` → go to top of file  
  - `G` → go to bottom of file  

---

# Micro Editor

Micro is a modern terminal-based text editor that aims to be **easy to use** while still being powerful.  
It feels similar to graphical editors, but runs entirely inside the terminal.

---

## Key Features

* Mouse or touch support  
* Syntax highlighting for many languages  
* Undo/redo with standard shortcuts  
* Multiple cursors and split panes  
* Configurable and extendable with plugins  

---

### Basic Shortcuts

| Action | Shortcut |
|--------|-----------|
| Save file | `Ctrl + S` |
| Quit | `Ctrl + Q` |
| Undo | `Ctrl + Z` |
| Redo | `Ctrl + Y` |
| Find text | `Ctrl + F` |
| Open new file | `Ctrl + E`, then type `open <filename>` |
| Split view | `Ctrl + E`, then type `vsplit <filename>` |

---

#### Tips

* Micro stores its config at `~/.config/micro/settings.json`.  
* You can install plugins easily:  
  - `Ctrl + E`, then `plugin install <plugin_name>`  
* To list available plugins:  
  - `Ctrl + E`, then `plugin list`  
* Great for users who want something **simpler than Vim but more powerful than Nano**.

---

##### Summary of Micro

Micro combines the comfort of modern editors with the lightness of the terminal.  
It’s perfect for quick edits or even long coding sessions inside Termux.

---

## GNU Emacs (or Emacs)
 
Emacs is a powerful and extensible text editor — often described as *“an operating system inside a text editor”*.  
It’s highly customizable through **Emacs Lisp**, its built-in scripting language.

## Philosophy

Emacs isn’t just for editing text: it’s designed to be **infinitely extendable**.  
You can turn it into a code editor, note-taking app, email client, music player, or even a game hub — all inside the same interface.

---

## Basic Shortcuts

| Action | Shortcut |
|--------|-----------|
| Open file | `Ctrl + X, Ctrl + F` |
| Save file | `Ctrl + X, Ctrl + S` |
| Exit Emacs | `Ctrl + X, Ctrl + C` |
| Cut text | `Ctrl + W` |
| Copy text | `Alt + W` |
| Paste text | `Ctrl + Y` |
| Undo | `Ctrl + /` |
| Cancel command | `Ctrl + G` |


## Tips

* Emacs uses its own **keybinding system**, which may feel strange at first.  
- You can install packages using **M-x package-install**.  
* Everything can be configured via `~/.emacs` or `~/.emacs.d/init.el`.  
* Emacs supports full color themes, syntax highlighting, and even graphical modes.  

---

## Summary for Emacs

Emacs is not only a text editor — it’s a *lifestyle choice*.  
If you like deep customization and total control, Emacs can become your personal digital workspace.
