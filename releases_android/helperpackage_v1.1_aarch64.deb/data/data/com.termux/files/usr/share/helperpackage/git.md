# Git Basics

`git` is a version control system used to track code changes and collaborate with others.


## Installation

install with:
```
apt install git
```
or termux:

```
pkg install git
```
---

## Setup

Before using Git, you need to register your user information.  
This identifies your commits and pushes.

```
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

You can check your settings with:
```
git config --list
```

---

## Creating a Repository

To start tracking a project, initialize Git in a folder:
```
git init
```

Add files to the staging area:
```
git add filename
git add .
```

Commit your changes:
```
git commit -m "First commit"
```

---

## Connecting to GitHub or Remote Repository

Add a remote connection:
```
git remote add origin https://github.com/username/repo.git
```

Push your commits to the repository:
```
git push -u origin main
```

If you haven’t logged in before, Git will ask for your credentials.

---

## Cloning Repositories

To download (clone) an existing repository:
```
git clone https://github.com/username/repo.git
```

---

## Pulling Updates

To fetch the latest changes from the remote repo:
```
git pull
```

---

## Tips

- Always `git pull` before pushing new commits.
- Use meaningful commit messages.
- For GitHub, consider using SSH keys to avoid typing your password every time:
  ```
  ssh-keygen -t ed25519 -C "your_email@example.com"
  ```


