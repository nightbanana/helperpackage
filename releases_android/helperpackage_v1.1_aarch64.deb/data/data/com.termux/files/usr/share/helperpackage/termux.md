# Termux-tools Overview

## Termux and Android

Termux have a Big variety of interactions, and you can get Many Functions that can help you!

## Termux-API

termux api is an application that allows you to interact with more functions of android.

1. setting Termux-API

* install Termux-api application *available in F-Droid*

* install termux-api package with `pkg install termux-api`


### using Termux-API

|useful functions|Description|
|-------------|-----------|
|`termux-clipboard-set [text]`|set the text as a clipboard item to paste anywhere| 
|termux-media-scan [directory]|as longer as its not a directory inside termux (like home), it will force the gallery in your phone to look for new pictures.|
|termux-notification|send notifications through termux-API app|

---

## termux-x11

termux-x11 allows you to run a graphical interface (GUI) in your phone. to do this, check this setup:

* install termux-x11-nightly;
```
pkg install termux-x11-nightly
```

* download termux-x11 application
* install x11 repo for available GUI packages;
```
pkg install x11-repo
```
---

### running termux-x11 app

to run graphical interfaces, first, we need to set up the termux-x11 session;

```
export DISPLAY=:0
termux-x11 :0 &
```
*open termux-x11 app first and let it run in background*

then, select a graphical interface or a wm to use
*obs: wm means Window Manager, such as i3wm*

---

##### • Setting up a Graphical interface

the good available options you can use are:

1. xfce
2. lxde
3. lxqt
4. MATE

##### • Setting up a Window Manager

the good available options you can use are:

1. openbox
2. fluxbox
3. i3


and a bunch of other GUIs and WMs

### Setting XFCE

first, install XFCE and xfce4-session;
```
pkg install xfce4 xfce4-session
```
*optional* install xfce4-goodies
```
pkg install xfce4-goodies
```

##### run xfce session 

```
xfce4-session
```
then go to termux-x11 application and wait for The GUI appear!

---

## Phantom Process Killer

in newer androids, the amount of processes is more limited if much apps are open, so Android starts killing them. to avoid this in termux-x11:

a github website to help solving this problem: https://github.com/atamshkai/Phantom-Process-Killer

---

# setting Openbox (or any WM) in termux-x11

the initial process of running the termux-x11 service with `termux-x11 :0 &` is the same.

after this, install openbox;

```
pkg install openbox
```

run termux-x11 and then just run openbox

```
openbox &
```
---

# Other Tools

yes, it exists many other tools, but it hasn't been mentioned here. this guide will be updated in the future and any help are being accepted!


