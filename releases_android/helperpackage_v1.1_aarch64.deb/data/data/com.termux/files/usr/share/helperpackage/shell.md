# SHELL — Command Line & Tools

The **shell** is a command-line interface that connects you directly to the system.  
It allows you to execute commands, run scripts, and combine tools in a powerful and flexible way.

---

## Understanding the Shell

A **shell** is simply a program that interprets text commands.

| Shell | Description |
|-------|--------------|
| **bash** | The most common shell — powerful and scriptable. |
| **zsh** | Similar to bash, but with better completion and themes. |
| **fish** | User-friendly shell with auto-suggestions. |
| **sh** | Simple, minimal shell used in basic scripts. |

---

## Core Concepts

| Concept | Explanation |
|----------|----------|
| **Pipe** | use the output of a command as the input of another command. |
| **Redirect (`>`, `<`)** | Save or read from files. example: `echo hi > msg.txt` |
| **Variables** | Store values. example: `user=$USER` then `echo $user` |
| **Permissions** | Manage execution rights. example: `chmod +x run.sh` |
| **Scripts** | Automate tasks. example: `bash script.sh` |

---

## Essential Built-ins

| Command | Description |
|----------|--------------|
| `ls`, `cd`, `pwd` | Navigation |
| `cp`, `mv`, `rm` | File management |
| `cat`, `echo`, `touch` | Text and file creation |
| `grep`, `cut`, `sort` | Text filtering |
| `chmod`, `chown` | Permissions |
| `man`, `help` | Documentation |

---

## General-purpose Tools

### fastfetch
Fast system information display in the terminal.  
It shows OS, kernel, CPU, memory, and other system details in a clean layout.  
Similar to **neofetch**, but faster and more customizable.

Usage:
```
fastfetch
fastfetch --logo small
```

---

### jq
A lightweight JSON processor.  
Allows you to **read, filter, and format JSON data** directly from the CLI.

Examples:
```
curl https://api.github.com/repos/user/repo | jq '.name'
jq '.users[0].name' data.json
```

---

### carbonyl
A **web browser that runs entirely in your terminal**.  
Useful for viewing websites without a GUI environment.

Examples:
```
carbonyl https://example.com
carbonyl https://github.com
```

---

### chafa
Convert images to ASCII or Unicode art directly in your terminal.  
Excellent for fun displays or low-resource environments.

Example:
```
chafa image.png --symbols=block
```

---

### bat
Like `cat`, but with **syntax highlighting** and line numbers.  
Great for reading code files quickly.

```
bat script.sh
```

---

### tldr
A simplified manual viewer.  
Shows short, practical command examples instead of full man pages.

```
tldr grep
```

---

## Tips and Tricks

| Shortcut | Description |
|-----------|--------------|
| `Ctrl + R` | Search in command history |
| `!!` | Repeat the last command |
| `!<word>` | Run the last command starting with `<word>` |
| `history` | View all previous commands |
| `alias ll='ls -la'` | Create command shortcuts |
| `&&` | Run next command only if the previous succeeds |

---

## Final Notes

The CLI is a **universal interface** — once you understand how tools combine,
you can manage systems, code, media, and networks efficiently.

> Each command does one thing well.  
> Together, they make the system infinite.
